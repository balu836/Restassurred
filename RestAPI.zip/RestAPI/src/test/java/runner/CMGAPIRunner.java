package runner;



import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import scenarioDefinations.Hooks;

@RunWith(Cucumber.class)

@CucumberOptions(features="restAPI.feature"
				,glue="scenarioDefinations"	
				,format= {"html:reports/html"}	
				,monochrome = true				
				)
public class CMGAPIRunner extends Hooks  {	

	public static void main(String[] args) {	
		
	}

}