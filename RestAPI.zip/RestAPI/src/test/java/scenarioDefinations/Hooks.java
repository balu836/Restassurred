package scenarioDefinations;

import java.awt.Color;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.Date;
import java.util.HashMap;

import org.junit.AfterClass;
import org.junit.BeforeClass;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;

public class Hooks {
	
	/**
	 * Document
	 */
	private static Document  document= new Document();
	
	/**
	 * PdfPTables
	 */
	public static  PdfPTable successTable = null;

	public static  PdfPTable failTable = null;
	
	public static PdfPTable summuryTable=null;
	public static int intPassedTCs=0,intFailedTCs=0,intTotalTCs=0;
	
	/**
	 * JyperionListener
	 */
	public static long startTime;
	public static long endTime ;
	
	public String file=null,filedummy=null;
	@SuppressWarnings("static-access")
	public Hooks() {		
		this.document = new Document();
		new HashMap<Integer, Throwable>();
	}	
	
	@BeforeClass
	public static void beforeClass() {
		
	}
	
	@Before
	public void beforeScenario(Scenario scenario) {
		
		startTime = System.nanoTime();    
	}
	
	@SuppressWarnings("static-access")
	@After
	public void afterScenario(Scenario scenario) {		
		String screenshotName = scenario.getName();
		endTime = System.nanoTime();
		if (scenario.isFailed()) {
			intFailedTCs+=intFailedTCs;
			
			if (this.failTable == null) {
				this.failTable = new PdfPTable(new float[]{.3f, .3f, .1f, .3f});
				this.failTable.setTotalWidth(20f);
				Paragraph p = new Paragraph("FAILED TESTS", new Font(Font.TIMES_ROMAN, Font.DEFAULTSIZE, Font.BOLD));
				p.setAlignment(Element.ALIGN_CENTER);
				PdfPCell cell = new PdfPCell(p);
				cell.setColspan(4);
				cell.setBackgroundColor(Color.RED);
				this.failTable.addCell(cell);
				
				cell = new PdfPCell(new Paragraph("TestCase"));
				cell.setBackgroundColor(Color.LIGHT_GRAY);
				this.failTable.addCell(cell);
				cell = new PdfPCell(new Paragraph("Scenario"));
				cell.setBackgroundColor(Color.LIGHT_GRAY);
				this.failTable.addCell(cell);
				cell = new PdfPCell(new Paragraph("Time (ms)"));
				cell.setBackgroundColor(Color.LIGHT_GRAY);
				this.failTable.addCell(cell);
				cell = new PdfPCell(new Paragraph("Status"));
				cell.setBackgroundColor(Color.LIGHT_GRAY);
				this.failTable.addCell(cell);
			}
			
			PdfPCell cell = new PdfPCell(new Paragraph(screenshotName.toString()));
			this.failTable.addCell(cell);
			cell = new PdfPCell(new Paragraph(screenshotName.toString()));
			this.failTable.addCell(cell);
			cell = new PdfPCell(new Paragraph("" + (endTime-startTime)));
			this.failTable.addCell(cell);
			cell = new PdfPCell(new Paragraph("Fail"));
			this.failTable.addCell(cell);	
			
			
		}else {
			intPassedTCs+=intPassedTCs;
			if (successTable == null) {
				this.successTable = new PdfPTable(new float[]{.3f, .3f, .1f, .3f});
				Paragraph p = new Paragraph("PASSED TESTS", new Font(Font.TIMES_ROMAN, Font.DEFAULTSIZE, Font.BOLD));
				p.setAlignment(Element.ALIGN_CENTER);
				PdfPCell cell = new PdfPCell(p);
				cell.setColspan(4);
				cell.setBackgroundColor(Color.GREEN);
				this.successTable.addCell(cell);				
				cell = new PdfPCell(new Paragraph("TestCase"));
				cell.setBackgroundColor(Color.LIGHT_GRAY);
				this.successTable.addCell(cell);
				cell = new PdfPCell(new Paragraph("Scenario"));
				cell.setBackgroundColor(Color.LIGHT_GRAY);
				this.successTable.addCell(cell);
				cell = new PdfPCell(new Paragraph("Time (ms)"));
				cell.setBackgroundColor(Color.LIGHT_GRAY);
				this.successTable.addCell(cell);
				cell = new PdfPCell(new Paragraph("Exception"));
				cell.setBackgroundColor(Color.LIGHT_GRAY);
				this.successTable.addCell(cell);
			}
			
			
			PdfPCell cell = new PdfPCell(new Paragraph(screenshotName.toString()));
			this.successTable.addCell(cell);
			cell = new PdfPCell(new Paragraph(screenshotName.toString()));
			this.successTable.addCell(cell);
			cell = new PdfPCell(new Paragraph("" + (endTime-startTime)));
			this.successTable.addCell(cell);
			cell = new PdfPCell(new Paragraph("Pass"));
			this.successTable.addCell(cell);
		}
		
		}	
	
	
	
	@AfterClass
	public static  void afterClass() throws FileNotFoundException, DocumentException {
				
		
		PdfWriter.getInstance(document, new FileOutputStream("..\\Reports\\RestAPIReport.pdf"));
		document.open();
		Paragraph p = new Paragraph("RestAPIReport" + " TESTNG RESULTS",
				FontFactory.getFont(FontFactory.HELVETICA, 20, Font.BOLD, new Color(0, 0, 255)));
		document.add(p);
		document.add(new Paragraph(new Date().toString()));		
		
			
		try {
			if (summuryTable != null) 
			{			
			 summuryTable.setSpacingBefore(15f);
			document.add(summuryTable);
			summuryTable.setSpacingAfter(15f);
		    }
			
			if (failTable != null) {
				
				failTable.setSpacingBefore(15f);
				document.add(failTable);
				failTable.setSpacingAfter(15f);
			}		
			if (successTable != null) {
				
				successTable.setSpacingBefore(15f);
				document.add(successTable);
				successTable.setSpacingBefore(15f);
			}
			document.close();

		} catch (DocumentException e) {
			e.printStackTrace();
		}
	}
	
}
