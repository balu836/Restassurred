package scenarioDefinations;

import static io.restassured.RestAssured.given;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.xml.DOMConfigurator;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import utility.Log;
import Libraries.*;

public class RestAPI  {
	 
	public static String getSessionId;
	public static String id;
	public static Response res;
	public static Log log;
	public static  Properties prop;	
	public static String strDefectId;
	
	
	 public RestAPI() throws IOException {
		 File file= new File("C:\\Users\\balu2\\eclipse-workspace\\cmgRestAPI\\configs\\configaration.properties");
		 FileInputStream fileInput = new FileInputStream(file);
		 prop = new Properties();
		 prop.load(fileInput);
		 DOMConfigurator.configure(prop.getProperty("log4jConfigPath"));		 
	}	
	
	@Given("^Connect the JIRA Host$")
	public void connect_the_JIRA_Host() throws Throwable {	
		Log.info("Getting JIRA Seesion");
		
		getSessionId=Resources.getJiraSessionId(); 
		
	}

	@When("^Create the defect with \"([^\"]*)\" and \"([^\"]*)\"$")
	public void create_the_defect_with_and(String strSummary, String strDescription) throws Throwable {
		Log.info("Creating JIRA Defect");	
		System.out.println("Create JIRA Session ID: "+getSessionId);
		RestAssured.baseURI=prop.getProperty("baseURI");		
		 res=given().header("Content-Type", "application/json").
				header("Cookie","JSESSIONID="+getSessionId).
				body(Payloads.createDefect(strSummary,strDescription)).when().
				post(Resources.getCreateRes()).then().extract().response();	
		 		JsonPath js = GenFunctions.rawToJsonFormat(res);
		 		strDefectId=js.get("id");
		 		System.out.println(strDefectId);
		 		//System.out.println(js.toString());
	}

	@Then("^Verify the Responce of Create JIRA$")
	public void verify_the_Responce_of_Create_JIRA() throws Throwable {
		Log.info("Comaparing Responce");			
		res.then().statusCode(201);
	}
	
	@When("^Update the Comments for \"([^\"]*)\"$")
	public void update_the_Comments_for(String strDefectID) throws Throwable {
		strDefectID=strDefectId;		
		Log.info("Updating JIRA Defect");		
		RestAssured.baseURI=prop.getProperty("baseURI");		
		 res=given().header("Content-Type", "application/json").
				header("Cookie","JSESSIONID="+getSessionId).
				body(Payloads.updateDefect()).when().
				post(Resources.addingComment(strDefectID)).then().extract().response();    
	}
	
	@Then("^Verify the Responce of Update JIRA$")
	public void verify_the_Responce_of_Update_JIRA() throws Throwable {
		Log.info("Comaparing Responce");			
		res.then().statusCode(204);    
	}
	
	@When("^Adding the Comments for \"([^\"]*)\" with \"([^\"]*)\"$")
	public void Add_the_Comments_for_with(String strDefectID, String strComment) throws Throwable {
        strDefectID=strDefectId;		
		Log.info("Create JIRA Defect");		
		RestAssured.baseURI=prop.getProperty("baseURI");		
		 res=given().header("Content-Type", "application/json").
				header("Cookie","JSESSIONID="+getSessionId).
				body(Payloads.updatingComment(strComment)).when().
				put(Resources.updatingComment(strDefectID)).then().extract().response(); 
	   
	}
	
	@When("^Delete Defect \"([^\"]*)\" in JIRA$")
	public void delete_Defect_in_JIRA(String strDefectID) throws Throwable {
		Log.info("Deleting JIRA Defect");		
		RestAssured.baseURI=prop.getProperty("baseURI");		
		 res=given().header("Content-Type", "application/json").
				header("Cookie","JSESSIONID="+getSessionId).
				when().
				delete(Resources.deleteDefect(strDefectID)).then().extract().response(); 	   
	}
	
	@Then("^Verify the Responce (\\d+) of Delete JIRA$")
	public void verify_the_Responce_of_Delete_JIRA(int intResponceCode) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		res.then().statusCode(intResponceCode); 
	}
	
	@Then("^Verify the Responce \"([^\"]*)\" of Delete JIRA$")
	public void verify_the_Responce_of_Delete_JIRA(String intResponceCode) throws Throwable {
	    
		int responceCode=Integer.parseInt(intResponceCode);
		res.then().statusCode(responceCode); 
	    
	}
	
	


	
}
