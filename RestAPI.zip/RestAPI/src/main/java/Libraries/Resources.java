package Libraries;


import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class Resources {
	
	public static String getSessionRes() {
		String strSessionRes="/rest/auth/1/session";
		return strSessionRes;
		
	}
	
	public static String getCreateRes() {
		String strCreateRes="/rest/api/2/issue";
		return strCreateRes;
		
	}
	
	public static String addingComment(String strDefectId) {
		String strUpdateComment="/rest/api/2/issue/"+strDefectId+"/comment";
		return strUpdateComment;
	}
	
	public static String updatingComment(String strDefectId) {
		//String strUpdateComment="/rest/api/2/issue/"+strDefectId+"/comment";
		String strUpdateComment="/rest/api/2/issue/"+strDefectId;		
		return strUpdateComment;
	}
	
	public static String deleteDefect(String strDefectId) {
		String strDelete="/rest/api/2/issue/"+strDefectId+"?deleteSubtasks";
		return strDelete;
	}
	
public static String getJiraSessionId() {
		
		RestAssured.baseURI="http://localhost:8080";
		Response res=  io.restassured.RestAssured.given().header("Content-Type","application/json")	
					 .body(Payloads.sessionId())
			.when()
				.post(getSessionRes())		
			.then()
				.extract().response();
			 String rs= res.asString();
			//System.out.println(rs);
			 JsonPath js= new JsonPath(rs);
			 String strSeesion = js.get("session.value");
			// System.out.println(strSeesion);
			 return strSeesion;			 
	}



}
