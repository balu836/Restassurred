package Libraries;


public class Payloads {
	
	public static String updateDefect() {
		String str="{\r\n" + 
				"    \"body\": \"This is a comment regarding the quality of the response.\"\r\n" + 
				"}";
		
		return str;
	}
	
	public static String updatingComment(String strComment) {
		
		String str="{\r\n" + 
				"   \"update\": {\r\n" + 
				"      \"comment\": [\r\n" + 
				"         {\r\n" + 
				"            \"add\": {\r\n" + 
				"               \"body\": "+strComment+"\r\n" + 
				"            }\r\n" + 
				"         }\r\n" + 
				"      ]\r\n" + 
				"   }\r\n" + 
				"}";
		
		return str;
	}
	
	public static String createDefect(String strSummary,String strDescription) {		
		
		String strData="{\r\n" + 
				"    \"fields\": {\r\n" + 
				"       \"project\":\r\n" + 
				"       {\r\n" + 
				"          \"key\": \"RES1\"\r\n" + 
				"       },\r\n" + 
				"       \"summary\": "+strSummary+", \r\n" + 
				"       \"description\":"+ strDescription+",\r\n" + 
				"       \"issuetype\": {\r\n" + 
				"          \"name\": \"Bug\"\r\n" + 
				"       }\r\n" + 
				"   }\r\n" + 
				"}";
		return strData;
		
	}
	
	public static String sessionId() {
		String strData="{\"username\": \"balu123\", \"password\": \"Jira123\"}";
		return strData;
	}
	

}
