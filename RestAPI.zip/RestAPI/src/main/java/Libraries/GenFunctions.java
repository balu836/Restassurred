package Libraries;


import io.restassured.path.json.JsonPath;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;


public class GenFunctions {
		public static JsonPath rawToJsonFormat(Response Responce) {
		String Response= Responce.asString();
		JsonPath JsonPath = new JsonPath(Response);		
		return JsonPath;		
	}
	
	public static XmlPath rawToXmlFormat(Response Responce) {
		String Response= Responce.asString();
		XmlPath XmlPath = new XmlPath(Response);		
		return XmlPath;		
	}

}
